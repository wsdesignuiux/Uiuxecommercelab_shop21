package model;

public class Order_pnd_model {

    public static final int Food_Type=0;
    public static final int Customer_Type=1;
    public int type;


    String textview1_food,textview_price;
    String placingorder_tv,customer1_tv,customer2_tv;

    public Order_pnd_model(int type, String textview1_food, String textview_price, String placingorder_tv, String customer1_tv, String customer2_tv) {
        this.type = type;
        this.textview1_food = textview1_food;
        this.textview_price = textview_price;
        this.placingorder_tv = placingorder_tv;
        this.customer1_tv = customer1_tv;
        this.customer2_tv = customer2_tv;
    }

    public String getTextview1_food() {
        return textview1_food;
    }

    public void setTextview1_food(String textview1_food) {
        this.textview1_food = textview1_food;
    }

    public String getTextview_price() {
        return textview_price;
    }

    public void setTextview_price(String textview_price) {
        this.textview_price = textview_price;
    }

    public String getPlacingorder_tv() {
        return placingorder_tv;
    }

    public void setPlacingorder_tv(String placingorder_tv) {
        this.placingorder_tv = placingorder_tv;
    }

    public String getCustomer1_tv() {
        return customer1_tv;
    }

    public void setCustomer1_tv(String customer1_tv) {
        this.customer1_tv = customer1_tv;
    }

    public String getCustomer2_tv() {
        return customer2_tv;
    }

    public void setCustomer2_tv(String customer2_tv) {
        this.customer2_tv = customer2_tv;
    }
}
