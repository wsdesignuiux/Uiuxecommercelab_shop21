package adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import e.wolfsoft1.orders_pnd_vp.R;
import model.Order_pnd_model;

public class Order_png_adapter extends RecyclerView.Adapter {

    private ArrayList<Order_pnd_model> dataSet;
    Context mContext;

    public Order_png_adapter(ArrayList<Order_pnd_model> dataSet, Context mContext) {
        this.dataSet = dataSet;
        this.mContext = mContext;
    }

    public class CustomerViewHolder extends RecyclerView.ViewHolder {
        TextView placingorder_tv, customer1_tv, customer2_tv;

        public CustomerViewHolder(@NonNull View itemView) {
            super(itemView);
            placingorder_tv = itemView.findViewById(R.id.placingorder_tv);
            customer1_tv = itemView.findViewById(R.id.customer1_tv);
            customer2_tv = itemView.findViewById(R.id.customer2_tv);

        }
    }


    public class FoodViewHolder extends RecyclerView.ViewHolder {

        TextView textview1_food, textview_price;

        public FoodViewHolder(@NonNull View itemView) {
            super(itemView);

            textview1_food = itemView.findViewById(R.id.textview1_food);
            textview_price = itemView.findViewById(R.id.textview_price);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        switch (i) {
            case Order_pnd_model.Food_Type:
                view = LayoutInflater.from(mContext).inflate(R.layout.item_food, viewGroup, false);
                return new FoodViewHolder(view);
            case Order_pnd_model.Customer_Type:
                view = LayoutInflater.from(mContext).inflate(R.layout.item_customer, viewGroup, false);
                return new CustomerViewHolder(view);

        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {

        switch (dataSet.get(position).type) {
            case 0:
                return Order_pnd_model.Food_Type;
            case 1:
                return Order_pnd_model.Customer_Type;

            default:
                return -1;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {


        Order_pnd_model object = dataSet.get(i);
        if (object != null) {
            switch (object.type) {
                case Order_pnd_model.Food_Type:
                    ((FoodViewHolder) viewHolder).textview1_food.setText(object.getTextview1_food());
                    ((FoodViewHolder) viewHolder).textview_price.setText(object.getTextview_price());


                    break;
                case Order_pnd_model.Customer_Type:
                    ((CustomerViewHolder) viewHolder).placingorder_tv.setText(object.getPlacingorder_tv());
                    ((CustomerViewHolder) viewHolder).customer1_tv.setText(object.getCustomer1_tv());
                    ((CustomerViewHolder) viewHolder).customer2_tv.setText(object.getCustomer2_tv());

                    break;
            }
        }


}

    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}
